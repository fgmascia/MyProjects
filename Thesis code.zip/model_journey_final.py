from packages import *

predictor = "name"
target = "subCategory"

df = pd.read_csv("data.csv")
df = df.drop_duplicates([predictor])
df[predictor] = df[predictor].astype(str)
df["journey"] = df["journey"].str.replace(r"[|/]", "-")
df['j_count'] = df.groupby("journey")["journey"].transform('count')
df = df.loc[df['j_count'] >= 50]

def get_data(product_type):
    df2 = df[df['journey']==product_type]
    print(df2["journey"].value_counts())
    return df2
    
# Text cleaning proved to be unnecessary
#default_stemmer = PorterStemmer()
#default_stopwords = stopwords.words('english')
#def clean_text(text, ):
#    def tokenize_text(text):
#       return [w for s in sent_tokenize(text) for w in word_tokenize(s)]
#    def remove_special_characters(text, characters=string.punctuation.replace('-', '')):
#        tokens = tokenize_text(text)
#        pattern = re.compile('[{}]'.format(re.escape(characters)))
#        return ' '.join(filter(None, [pattern.sub('', t) for t in tokens]))
#    def remove_stopwords(text, stop_words=default_stopwords):
#        tokens = [w for w in tokenize_text(text) if w not in stop_words]
#        return ' '.join(tokens)
#    def stem_text(text, stemmer=default_stemmer):
#        tokens = tokenize_text(text)
#        return ' '.join([stemmer.stem(t) for t in tokens])
#    text = text.lower() # lowercase
#    text = remove_special_characters(text) # remove punctuation and symbols
#    text = remove_stopwords(text) # remove stopwords
#   text = stem_text(text) # stemming
#    return text

#def pipelinize(function, active=True):
#    def list_comprehend_a_function(list_or_series, active=True):
#        if active:
#            return [function(i) for i in list_or_series]
#        else:
#            return list_or_series
#    return FunctionTransformer(list_comprehend_a_function, validate=False, kw_args={'active':active})

def model(df2, Journey):
    model = RandomForestClassifier(n_estimators = 10, random_state = 42)
    vectorizer = CountVectorizer(decode_error="replace")
    tfidf_transformer = TfidfTransformer(use_idf=True) 
    text_pipe = Pipeline([#("clean", pipelinize(clean_text)),
                         ("encoder", vectorizer), ("transform", tfidf_transformer)
                         ])
    mod = Pipeline([("encoder", text_pipe),
                    ("model", model),
                    ])
    mod_fit = mod.fit(df2[predictor], df2[target])  
    return mod_fit

def process_journey(Journey):
    data = get_data(Journey)
    mymodel = model(data, Journey)
    joblib.dump(mymodel, target+"_"+Journey+".joblib")
    return mymodel

def main():
    for journey in df["journey"].unique():
        print("Processing Journey:", journey)
        try:
            final = process_journey(journey)
            print(final)
        except Exception as e:
            print("Error occurred for journey:",journey,":",str(e))
         
main()

