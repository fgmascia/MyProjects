from packages import *

predictor = "name"
# Insert either subCategory, subBrand or manufacturer
target = "subCategory"

df = pd.read_csv("data.csv")
df = df.drop_duplicates([predictor])
df[predictor] = df[predictor].astype(str)

df = pd.read_csv("data.csv")
df = df.drop_duplicates([predictor])
df[predictor] = df[predictor].astype(str)
df = df.loc[df["journey"]=="Beer"]

def get_data(df):
    df['class_size'] = df.groupby(target)[target].transform('count')
    df = df.loc[df['class_size'] >= 20]
    return df

#default_stemmer = PorterStemmer()
#default_stopwords = stopwords.words('english')
#def clean_text(text, ):
#    def tokenize_text(text):
#       return [w for s in sent_tokenize(text) for w in word_tokenize(s)]
#    def remove_special_characters(text, characters=string.punctuation.replace('-', '')):
#        tokens = tokenize_text(text)
#        pattern = re.compile('[{}]'.format(re.escape(characters)))
#        return ' '.join(filter(None, [pattern.sub('', t) for t in tokens]))
#    def remove_stopwords(text, stop_words=default_stopwords):
#        tokens = [w for w in tokenize_text(text) if w not in stop_words]
#        return ' '.join(tokens)
#    def stem_text(text, stemmer=default_stemmer):
#        tokens = tokenize_text(text)
#        return ' '.join([stemmer.stem(t) for t in tokens])
#    text = text.lower() # lowercase
#    text = remove_special_characters(text) # remove punctuation and symbols
#    text = remove_stopwords(text) # remove stopwords
#   text = stem_text(text) # stemming
#    return text

#def pipelinize(function, active=True):
#    def list_comprehend_a_function(list_or_series, active=True):
#        if active:
#            return [function(i) for i in list_or_series]
#        else:
#            return list_or_series
#    return FunctionTransformer(list_comprehend_a_function, validate=False, kw_args={'active':active})

def model(df):
    #model = LogisticRegression() 
    #model = MultinomialNB()
    #model = svm.SVC(gamma='scale', decision_function_shape='ovo')
    model = RandomForestClassifier(n_estimators = 10, random_state = 42)
    #model = RandomForestClassifier(n_estimators = 100, random_state = 42) 
    vectorizer = CountVectorizer(decode_error="replace")
    tfidf_transformer = TfidfTransformer(use_idf=True) 
    text_pipe = Pipeline([#("clean", pipelinize(clean_text)),
                         ("encoder", vectorizer), ("transform", tfidf_transformer)
                         ])
    train_predictor, test_predictor, train_target, test_target = train_test_split(df, df[target], test_size = 0.2, random_state = 42)
    mod = Pipeline([("encoder", text_pipe),
                    ("model", model),
                    ])
    mod_fit = mod.fit(train_predictor[predictor], train_target)  
    y_pred = mod_fit.predict(test_predictor[predictor])
    #return accuracy_score(y_pred, test_target)
    return classification_report(test_target, y_pred) 

def process():
    data = get_data(df)
    mymodel = model(data)
    return mymodel

def main():
    final = process()
    print(final)

main()

