from imdb_helper2_data import *


def RNN_one(learning_rate, epochs, batches):
    
    print('Loading data...')
    print(len(x_train), 'train sequences')
    print(len(x_test), 'test sequences')
    print('Pad sequences (samples x time)')
    print('x_train shape:', x_train.shape)
    print('x_test shape:', x_test.shape)

    print('Build model...')
    model = Sequential()

    model.add(Embedding(max_features, 32))
    model.add(GRU(32, activation='relu', dropout=0.2, recurrent_dropout=0.2, return_sequences=True))
    model.add(GRU(32, activation='relu', dropout=0.2, recurrent_dropout=0.2))
    model.add(Dense(1, activation='sigmoid'))

    model.compile(loss='binary_crossentropy',
                  optimizer=optimizers.RMSprop(lr=learning_rate),
                  metrics=['accuracy'])

    tensorboard = TensorBoard(log_dir="logs/{}".format(time()))  

    print('Train...')
    model.fit(x_train, y_train, batch_size=batches, epochs=epochs, verbose=1, validation_data=(x_test, y_test), callbacks=[tensorboard])

    model.save('imdb-final.ckpt')

def RNN_two(learning_rate, epochs, batches):
   
    print('Loading data...')
    print(len(x_train), 'train sequences')
    print(len(x_test), 'test sequences')
    print('Pad sequences (samples x time)')
    print('x_train shape:', x_train.shape)
    print('x_test shape:', x_test.shape)

    print('Build model...')
    model = Sequential()

    model.add(Embedding(input_dim=10000, output_dim=32))
    model.add(GlobalMaxPool1D())
    model.add(Dense(16, activation='relu'))
    model.add(Dense(1, activation='sigmoid'))

    model.compile(optimizer=optimizers.RMSprop(lr=learning_rate),
                  loss='binary_crossentropy',
                  metrics=['accuracy'])
    
    tensorboard = TensorBoard(log_dir="logs/{}".format(time()))  

    print('Train...')
    model.fit(x_train, y_train, batch_size=batches, epochs=epochs, verbose=1, validation_data=(x_test, y_test), callbacks=[tensorboard])

    model.save('imdb-final2.ckpt')
    