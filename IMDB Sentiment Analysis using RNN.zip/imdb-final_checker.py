from tensorflow import keras
from imdb_helper2_data import *

new_model = keras.models.load_model('imdb-final.ckpt')
new_model.summary()
score = new_model.evaluate(x_test, y_test, verbose=0)
print('Test accuracy:', score[1])