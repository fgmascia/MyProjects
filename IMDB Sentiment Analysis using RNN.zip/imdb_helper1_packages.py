from __future__ import print_function
import argparse
from tensorflow import keras
from keras import optimizers
from keras import layers
from keras.models import Sequential
from keras.layers import Dense, Conv1D, Embedding, LSTM, GRU, GlobalMaxPool1D
from keras.datasets import imdb
from keras import regularizers
from time import time
from keras.callbacks import TensorBoard
