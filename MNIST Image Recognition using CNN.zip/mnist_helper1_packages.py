from __future__ import print_function
import argparse
from keras.models import Sequential
from keras.layers import Dense, Conv2D, Flatten, MaxPool2D, Dropout
from keras.datasets import mnist
from keras.utils import to_categorical
from keras.optimizers import RMSprop
from time import time
from keras.callbacks import TensorBoard