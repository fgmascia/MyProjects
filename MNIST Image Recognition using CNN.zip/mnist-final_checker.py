from tensorflow import keras
from mnist_helper2_data import *

new_model = keras.models.load_model('mnist-final.ckpt')
new_model.summary()
score = new_model.evaluate(x_test, y_test, verbose=0)
print('Test accuracy:', score[1])