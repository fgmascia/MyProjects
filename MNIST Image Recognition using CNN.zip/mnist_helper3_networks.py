from mnist_helper2_data import *

def CNN_one(learning_rate, epochs, batches):

    print('Loading data...')
    print(len(x_train), 'train sequences')
    print(len(x_test), 'test sequences')

    print('Build model...')
    model = Sequential()
    
    model = Sequential()
    model.add(Conv2D(32, (3, 3), activation='relu', input_shape=(28, 28, 1)))
    model.add(MaxPool2D(2, 2))
    model.add(Dropout(0.5))
    model.add(Conv2D(64, (3, 3), activation='relu'))
    model.add(MaxPool2D(2, 2))
    model.add(Dropout(0.5))
    model.add(Conv2D(64, (3, 3), activation='relu'))
    model.add(Flatten())
    model.add(Dense(128, activation='relu'))
    model.add(Dropout(0.5))
    model.add(Dense(10, activation='softmax'))
    
    optimizer = RMSprop(lr=learning_rate, rho=0.9, epsilon=1e-08, decay=0.0)

    model.compile(optimizer=optimizer, loss="categorical_crossentropy", metrics=["accuracy"])

    tensorboard = TensorBoard(log_dir="logs/{}".format(time()))  

    print('Train...')
    model.fit(x_train, y_train, batch_size=batches, epochs=epochs, verbose=2, validation_data=(x_test, y_test), callbacks=[tensorboard])
    
    model.save('mnist-final.ckpt')

    
def CNN_two(learning_rate, epochs, batches):
   
    print('Loading data...')
    print(len(x_train), 'train sequences')
    print(len(x_test), 'test sequences')

    print('Build model...')
    model = Sequential()
    
    model.add(Conv2D(64, kernel_size=3, activation='relu', input_shape=(28, 28, 1)))
    model.add(Conv2D(32, kernel_size=3, activation='relu'))
    model.add(Flatten())
    model.add(Dense(10, activation='softmax'))
    
    optimizer = RMSprop(lr=learning_rate, rho=0.9, epsilon=1e-08, decay=0.0)

    model.compile(optimizer=optimizer, loss="categorical_crossentropy", metrics=["accuracy"])
    
    tensorboard = TensorBoard(log_dir="logs/{}".format(time()))
   
    print('Train...')
    model.fit(x_train, y_train, batch_size=batches, epochs=epochs, verbose=1, validation_data=(x_test, y_test), callbacks=[tensorboard])

    model.save('mnist-final2.ckpt')
